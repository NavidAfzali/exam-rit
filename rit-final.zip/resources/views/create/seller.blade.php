@extends('layouts.template')
@section('content')
@include('layouts.navigation')
    <h1 class="h1 m-5"> فروشنده جدید</h2>
    <div class="m-5 p-5 overflow-hidden shadow-sm sm:rounded-lg bg-info">
        <form action="{{ route('store-seller') }}" method="post">
            @csrf
            <div class="mb-3">
                <label for="title" class="form-label"> نام شرکت :</label>
                <input type="text" name="name" class="form-control" id="title">
            </div>
        
            <div class="mb-3">
                <label for="score" class="form-label">امتیاز :</label>
                <input type="text" name="score" class="form-control" id="score">
            </div> 
            
            <button type="submit" class="btn btn-primary">ثبت</button>
        </form>
    </div>
    
@endsection