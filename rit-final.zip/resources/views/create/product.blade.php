@extends('layouts.template')
@section('content')
@include('layouts.navigation')
    <h1 class="h1 m-5"> محصول جدید</h2>
    <div class="m-5 p-5 overflow-hidden shadow-sm sm:rounded-lg bg-info">
        <form action="{{ route('store-product') }}" method="post" enctype="multipart/form-data">
            @csrf
            <div class="mb-3">
                <label for="title" class="form-label">عنوان :</label>
                <input type="text" name="title" class="form-control" id="title">
            </div>
            <div class="mb-3">
                <label for="desc" class="form-label">توضیحات :</label>
                <textarea style="color: black;" name="description" id="desc" cols="175" rows="4"></textarea>
            </div>
            <div class="mb-3">
                <label for="price" class="form-label">قیمت :</label>
                <input type="text" name="price" class="form-control" id="price">
            </div>
            
            
            <div class="mb-3">
                <label for="formFile" class="form-label">تصویر :</label>
                <input class="form-control bg-white" name="image" type="file" id="formFile">
            </div>
            
            <button type="submit" class="btn btn-primary">ثبت</button>
        </form>
    </div>
    
@endsection