@extends('layouts.template')
@section('content')
@include('layouts.navigation')
    <h1 class="h1 m-5"> محصولات</h2>
        <div class="row m-5">
            @foreach ($products as $item)
            <div class="col">
                <div class="card h-100 bg-warning">
                    <img src="{{ asset('/storage/'. $item->image) }}" class="card-img-top" style="width:300px;height:200px;" alt="...">
                    @can('isAdmin')
                    <a href="/coupon/{{ $item->id }}"></a>
                    @endcan
                    @can('isUser')
                    <a href="/coupon/{{ $item->id }}" class="btn stretched-link"></a>
                    @endcan
                    <div class="card-body">
                        <h5 class="card-title h2">{{ $item->title }}</h5>
                        <p class="card-text">{{ $item->description }}</p>
                        @can('isAdmin')
                            <div class="d-flex">
                                <form action="{{ route('editForm-product') }}" method="get">
                                    @csrf
                                    <input name="id" value="{{ $item->id }}" hidden>
                                    <input class="m-1 p-2" type="submit" value="Edit" style="color:white;background-color: blue; border-radius:7px; width:70px;">
                                </form>
                                <form action="{{ route('delete-product') }}" method="post">
                                    @csrf
                                    @method('delete')
                                    <input name="id" value="{{ $item->id }}" hidden>
                                    <input class="m-1 p-2" type="submit" value="Delete" style="color:white;background-color: red; border-radius:7px;">
                                </form>
                            </div>
                        @endcan
                    </div>
                </div>
            </div>
            @endforeach
        </div>
    
    
@endsection