@extends('layouts.template')
@section('content')
@include('layouts.navigation')
    <h1 class="h1 m-5"> ویرایش محصول</h1>
    <h3 class="m-5 h3">{{ $product->title }}</h3>
    <div class="m-5 p-5 overflow-hidden shadow-sm sm:rounded-lg bg-info">
        <form action="{{ route('edit-product') }}" method="post" enctype="multipart/form-data">
            @csrf
            @method('patch')
            <div class="mb-3">
                <label for="title" class="form-label">عنوان :</label>
                <input type="text" name="title" value="{{ $product->title }}" class="form-control" id="title">
            </div>
            <div class="mb-3">
                <label for="desc" class="form-label">توضیحات :</label>
                <textarea style="color: black;"  name="description" id="desc" cols="175" rows="4"></textarea>
            </div>
            <div class="mb-3">
                <label for="price" class="form-label">قیمت :</label>
                <input type="text" name="price" value="{{ $product->price }}" class="form-control" id="price">
            </div>
            
            
            <div class="mb-3">
                <label for="formFile" class="form-label">تصویر :</label>
                <input class="form-control bg-white" name="image" type="file" id="formFile">
            </div>
            
            <button type="submit" class="btn btn-primary">ثبت</button>
        </form>
    </div>
    
@endsection