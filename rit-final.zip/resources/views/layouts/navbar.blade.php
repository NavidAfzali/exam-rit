<nav class="navbar navbar-expand-lg bg-light">
    <div class="container-fluid">
      <a class="navbar-brand" href="#">ایمالز</a>
      <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarSupportedContent" aria-controls="navbarSupportedContent" aria-expanded="false" aria-label="Toggle navigation">
        <span class="navbar-toggler-icon"></span>
      </button>
      @can('isUser')
      
      @endcan
      @if(!empty(auth()->user()))
      <button class="btn btn-outline-success" type="submit">
        <a href="/dashboard">{{ auth()->user()->name }}</a>
      </button>
      @else
      <button class="btn btn-outline-success" type="submit">
        <a href="/register">ثبت نام | ورود</a>
    </button>
      @endif
    </div>
    <div class="collapse navbar-collapse" id="navbarSupportedContent">
      
    </div>
  </nav>