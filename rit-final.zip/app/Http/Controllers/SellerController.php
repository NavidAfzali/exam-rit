<?php

namespace App\Http\Controllers;

use App\Models\Product;
use App\Models\Seller;
use Illuminate\Http\Request;

class SellerController extends Controller
{
    public function create()
    {
        return view('create.seller');
    }
    public function store(Request $request)
    {
        // dd($request);
        Seller::create([
            'name' => $request->name,
            'score' => $request->score,
        ]);
        return redirect('/dashboard');
    }
}
