<?php

namespace App\Http\Controllers;

use App\Models\Product;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Gate;

class ProductController extends Controller
{
    public function show()
    {
        $products = Product::all();
        if (! Gate::allows('isAdmin')) {
            abort(403);
        }
        return view('edit.product')->with(['products' => $products]);
    }
    public function edit(Request $request)
    {
        $product = Product::find($request->id);
        return view('edit.product-edit')->with(['product' => $product]);
    }

    public function edition(Request $request)
    {
        // dd($request);
        $path = $request->file('image')->storeAs(
            'images', $request->file('image')->getClientOriginalName(), 'public'
        );
        $t = Product::where('id', (int)$request->id)->update([
            'title' => $request->title,
            'description' => $request->description,
            'price' => $request->price,
            //'image' => $path,
        ]);
        dd($t);
        return redirect('/dashboard');
    }

    public function delete(Request $request)
    {
        if (! Gate::allows('isAdmin')) {
            abort(403);
        }
    }

    public function create(Request $request)
    {
        if (! Gate::allows('isAdmin')) {
            abort(403);
        }
        return view('create.product');
    }

    public function store(Request $request) 
    {
        if (! Gate::allows('isAdmin')) {
            abort(403);
        }
        $path = $request->file('image')->storeAs(
            'images', $request->file('image')->getClientOriginalName(), 'public'
        );
        // dd($request);

        Product::create([
            'title' => $request->title,
            'description' => $request->description,
            'price' => $request->price,
            'image' => $path,
        ]);
        return redirect('/dashboard');
    }
}
