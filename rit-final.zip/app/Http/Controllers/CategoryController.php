<?php

namespace App\Http\Controllers;

use App\Models\Category;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Gate;

class CategoryController extends Controller
{
    public function edit()
    {
        if (! Gate::allows('isAdmin')) {
            abort(403);
        }
    }

    public function edition(Request $request)
    {
        //
    }

    public function delete(Request $request)
    {
        if (! Gate::allows('isAdmin')) {
            abort(403);
        }
    }

    public function create(Request $request)
    {
        if (! Gate::allows('isAdmin')) {
            abort(403);
        }
        return view('create.category');
    }

    public function store(Request $request) 
    {
        if (! Gate::allows('isAdmin')) {
            abort(403);
        }
        $path = $request->file('image')->storeAs(
            'images', $request->file('image')->getClientOriginalName(), 'public'
        );
        // dd($request);
        Category::create([
            'name' => $request->name,
        ]);
        return redirect('/dashboard');
    }


}
