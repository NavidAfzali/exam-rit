<?php

use App\Http\Controllers\CategoryController;
use App\Http\Controllers\ProductController;
use App\Http\Controllers\ProfileController;
use App\Http\Controllers\SellerController;
use App\Http\Controllers\UserController;
use App\Models\Seller;
use Illuminate\Support\Facades\Route;

/*
|--------------------------------------------------------------------------
| Web Routes
|--------------------------------------------------------------------------
|
| Here is where you can register web routes for your application. These
| routes are loaded by the RouteServiceProvider within a group which
| contains the "web" middleware group. Now create something great!
|
*/

Route::get('/', function () {
    return view('homepage');
});

Route::get('/dashboard', function () {
    return view('dashboard');
})->middleware(['auth', 'verified'])->name('dashboard');

Route::middleware('auth')->group(function () {
    Route::get('/profile', [ProfileController::class, 'edit'])->name('profile.edit');
    Route::patch('/profile', [ProfileController::class, 'update'])->name('profile.update');
    Route::delete('/profile', [ProfileController::class, 'destroy'])->name('profile.destroy');
});

Route::prefix('/category')->group(function () {
    Route::get('/edit', [CategoryController::class, 'edit'])->name('editForm-cat');
    Route::post('/edit', [CategoryController::class, 'edition'])->name('edit-cat');
    Route::delete('/delete', [CategoryController::class, 'delete'])->name('delete-cat');
    Route::get('/create', [CategoryController::class, 'create'])->name('create-cat');
    Route::post('/store', [CategoryController::class, 'store'])->name('store-cat');

});

Route::prefix('/user')->group(function () {
    Route::get('/edit', [UserController::class, 'edit'])->name('editForm-user');
    Route::post('/edit', [UserController::class, 'edition'])->name('edit-user');
    Route::delete('/delete', [UserController::class, 'delete'])->name('delete-user');
    Route::get('/create', [UserController::class, 'create'])->name('create-user');
    Route::post('/store', [UserController::class, 'store'])->name('store-user');

});

Route::prefix('/seller')->group(function () {
    Route::get('/edit', [SellerController::class, 'edit'])->name('editForm-seller');
    Route::post('/edit', [SellerController::class, 'edition'])->name('edit-seller');
    Route::delete('/delete', [SellerController::class, 'delete'])->name('delete-seller');
    Route::get('/create', [SellerController::class, 'create'])->name('create-seller');
    Route::post('/store', [SellerController::class, 'store'])->name('store-seller');

});

Route::prefix('/product')->group(function () {
    Route::get('/show', [ProductController::class, 'show'])->name('show-product');
    Route::get('/edit', [ProductController::class, 'edit'])->name('editForm-product');
    Route::patch('/edit', [ProductController::class, 'edition'])->name('edit-product');
    Route::delete('/delete', [ProductController::class, 'delete'])->name('delete-product');
    Route::get('/create', [ProductController::class, 'create'])->name('create-product');
    Route::post('/store', [ProductController::class, 'store'])->name('store-product');

});

require __DIR__.'/auth.php';
