
<?php $__env->startSection('content'); ?>
<?php echo $__env->make('layouts.navigation', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <h1 class="h1 m-5"> محصولات</h2>
        <div class="row m-5">
            <?php $__currentLoopData = $products; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <div class="col">
                <div class="card h-100 bg-warning">
                    <img src="<?php echo e(asset('/storage/'. $item->image)); ?>" class="card-img-top" style="width:300px;height:200px;" alt="...">
                    <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('isAdmin')): ?>
                    <a href="/coupon/<?php echo e($item->id); ?>"></a>
                    <?php endif; ?>
                    <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('isUser')): ?>
                    <a href="/coupon/<?php echo e($item->id); ?>" class="btn stretched-link"></a>
                    <?php endif; ?>
                    <div class="card-body">
                        <h5 class="card-title h2"><?php echo e($item->title); ?></h5>
                        <p class="card-text"><?php echo e($item->description); ?></p>
                        <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('isAdmin')): ?>
                            <div class="d-flex">
                                <form action="<?php echo e(route('editForm-product')); ?>" method="get">
                                    <?php echo csrf_field(); ?>
                                    <input name="id" value="<?php echo e($item->id); ?>" hidden>
                                    <input class="m-1 p-2" type="submit" value="Edit" style="color:white;background-color: blue; border-radius:7px; width:70px;">
                                </form>
                                <form action="<?php echo e(route('delete-product')); ?>" method="post">
                                    <?php echo csrf_field(); ?>
                                    <?php echo method_field('delete'); ?>
                                    <input name="id" value="<?php echo e($item->id); ?>" hidden>
                                    <input class="m-1 p-2" type="submit" value="Delete" style="color:white;background-color: red; border-radius:7px;">
                                </form>
                            </div>
                        <?php endif; ?>
                    </div>
                </div>
            </div>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </div>
    
    
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.template', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\emergency\Laravel\rit-final\resources\views/edit/product.blade.php ENDPATH**/ ?>