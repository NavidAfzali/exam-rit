
<?php $__env->startSection('content'); ?>
<?php echo $__env->make('layouts.navigation', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <h1 class="h1 m-5"> فروشنده جدید</h2>
    <div class="m-5 p-5 overflow-hidden shadow-sm sm:rounded-lg bg-info">
        <form action="<?php echo e(route('store-seller')); ?>" method="post">
            <?php echo csrf_field(); ?>
            <div class="mb-3">
                <label for="title" class="form-label"> نام شرکت :</label>
                <input type="text" name="name" class="form-control" id="title">
            </div>
        
            <div class="mb-3">
                <label for="score" class="form-label">امتیاز :</label>
                <input type="text" name="score" class="form-control" id="score">
            </div> 
            
            <button type="submit" class="btn btn-primary">ثبت</button>
        </form>
    </div>
    
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.template', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\emergency\Laravel\rit-final\resources\views/create/seller.blade.php ENDPATH**/ ?>