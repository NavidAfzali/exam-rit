<nav class="navbar navbar-expand-lg bg-light">
    <div class="container-fluid">
      <a class="navbar-brand" href="#">ایمالز</a>
      <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarSupportedContent" aria-controls="navbarSupportedContent" aria-expanded="false" aria-label="Toggle navigation">
        <span class="navbar-toggler-icon"></span>
      </button>
      <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('isUser')): ?>
      
      <?php endif; ?>
      <?php if(!empty(auth()->user())): ?>
      <button class="btn btn-outline-success" type="submit">
        <a href="/dashboard"><?php echo e(auth()->user()->name); ?></a>
      </button>
      <?php else: ?>
      <button class="btn btn-outline-success" type="submit">
        <a href="/register">ثبت نام | ورود</a>
    </button>
      <?php endif; ?>
    </div>
    <div class="collapse navbar-collapse" id="navbarSupportedContent">
      
    </div>
  </nav><?php /**PATH D:\emergency\Laravel\rit-final\resources\views/layouts/navbar.blade.php ENDPATH**/ ?>